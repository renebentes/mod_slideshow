CHANGELOG
=============

Este arquivo refere-se às mudanças realizadas desde a versão inicial de desenvolvimento.

* 1.0.0 - 23/02/2015
  * Message - Release totalmente funcional para Joomla 3+
  * Updated - Alteração na licença do projeto
* 0.1.2 -
  * Added - Link para artigo na imagem
  * Added - Busca por imagem através de tags de plugin {gallery}pasta{/gallery}
  * Fixed - Exibição de links de navegação apenas com mais de 1 item retornado
  * Fixed - Exibição de links diretos para artigos conforme a quantidade retornada
* 0.1.1 -
  * Removed - Parâmetros de carregamento adicional de bibliotecas JavaScript e CSS
  * Added - Requisito funcionamento apenas em templates baseado em Twitter Bootstrap
  * Updated - Layout modificado com base na atualização do Twitter Bootstrap
* 0.1.0 - 28/08/2013
  * Message - Estágio inicial de desenvolvimento